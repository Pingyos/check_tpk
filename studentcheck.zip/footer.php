<footer class="site-footer">
    <div class="footer-inner bg-white">
        <div class="row">
            <div class="col-sm-6">
                โรงเรียนถ้ำปินวิทยาคม &copy; ระบบบันทึกเวลาเรียน พัฒนาโดย งานพัฒนาสื่อและเทคโนโลยี กลุ่มบริหารงานวิชาการ
            </div>
        </div>
    </div>
</footer>